# P780 GhostLock 适配进度（v0.2）

## 阶段结论

目前可以肯定：P780 的 Linux 5.4.233 内核配置具备 Futex PI、RT Mutex、Tracefs、ashmem；普通 Shell 成功写入并读取 Tracefs 事件，并通过原始页获得候选内核代码地址。TinnoOSS/P780（5.4.61）公开源码里可见 CVE-2026-43499 涉及的 `remove_waiter` 错误模式。不过仍**没有证明实际运行的 5.4.233 内核保留该错误，更没有获得 Root**。

## 可复核证据

1. `evidence/p780-config.gz`：39,170 字节，6,576 行配置。SHA-256：`0ff9cbb1844e043e1211b527509f5f435862cace25649bab6641d5d62c7bbce0`。
2. `evidence/p780-cpu4.raw`：4,096 字节，trace marker 位于 `0x2c`，小端 64 位候选 IP 位于 `0x24`，即 `0xffffffecdc1dc9c8`。SHA-256：`435e5e1d05767ebc7a65322a2da2599ad07c58c7277456cd96d6960620587fac`。
3. `target/p780-candidate.json`：固件指纹、内核和来源信息。
4. `target/upstream-qgki54-snapshot.json`：QGKI-5.4 stage 截止 2026-10-10 的 31 项事实清单。

## 新增工程交付

- 独立候选 Target、事实清单、离线脚本、自动测试和 Windows PowerShell 入口。
- 在目标身份/文件哈希/Config 检验全部通过时依然返回 `BLOCKED`，因为当前缺少 29 项上游 stage 的**已验证实机构建值**和精确内核镜像。
- 加入篡改原始追踪记录、无证据偏移、打开危险开关和不安全路径等 5 项回归测试。

## 下一项真正值得做的开发

离线进行 TinnoOSS 原厂 `futex.c`、`rtmutex.c` 的结构性对照，并把候选字段逐个分类。不在毫无精确内核符号/布局的条件下编译、运行堆对象伪造型利用链。真实内核二进制问题可以继续关注，但之前失败的 EDL/OTA 路线不重复。

## 明确未完成

- P780 `_162` 与 5.4.61 公共源码的二进制一致性。
- CVE-2026-43499 在当前真实运行二进制中的缺陷状态。
- 内核基址和相关全量偏移的正确测定。
- P780 专用 exploit 编译/验证、临时 Root、KernelSU。
- Bootloader 解锁（与内核 Root 属于独立目标）。

## 相关在线材料

- https://github.com/TinnoOSS/P780
- https://github.com/JingMatrix/pixel-ksu-root/blob/main/data/targets.json
- https://github.com/JingMatrix/pixel-ksu-root/blob/main/cves/targets/README.md
- https://github.com/JingMatrix/pixel-ksu-root/blob/main/runner/stages/entry.ghostlock%40qgki-5.4/stage.toml

## v0.2 补充：认识“31 项缺失”的含义

新的离线预检把前一版统一标记的 31 项 required facts 划分为不同证据等级。
`BUILD_FINGERPRINT` 已从之前真实 ADB 记录确认；`KERNEL_VERSION_CODE` 从 `5.4.233` 计算为十进制 `328937`（`0x504e9`）。这两项是身份/版本元数据，**不包含任何内核偏移，也不能用于执行漏洞**。剩余 29 项中既有编译结构/源码推断候选，也有必须依靠实际运行内核二进制证明的符号和栈布局。

`target/fact-matrix.json` 给出分类及证据门槛。预检不允许随意补入符号、内存偏移，并始终 `BLOCKED`。所有 v0.1 原始证据保持不变。


## v0.3（2026-10-10）

- 从用户上传的 `latest-preflight(1).json` 确认 v0.2：`errors=[]`、`verified_count=2`、`missing_count=29`、`status=BLOCKED`。
- 在线复核 TinnoOSS/P780 原始文件 `kernel/locking/rtmutex.c`、`kernel/futex.c`、`Makefile` 与 Linux 官方 2026 修复描述，形成明确的源码证据锚点。
- 新增独立源码模式检查工具。需要用户自行取得厂商源码；审查后仍将实机漏洞状态标记 `UNDETERMINED`。
- 扩展配置分析，单独呈现 CFI/LTO/栈与模块编译环境，不改变原有 31 项上游参数状态。
- 研究优先级：当前 `_162` 运行内核的准确二进制来源和行为证据。旧源码不能代替固件补丁验证。


## v0.4 — 2026-10-10

- 接收用户 v0.3 `source-audit.json`；`errors=[]`，P780 制造商旧源码有 CVE-like pattern。
- 增加上游 Linux v5.4.233 的官方源文件跨版本审计：该版本的 `remove_waiter()` 仍用 `current`。
- 新增 `tools/p780_version_bridge.py` 比较两份源码、输出 SHA256、目标函数结构及差异摘要，**不生成运行时偏移**。
- 风险判断：实机漏洞状态 `UNDETERMINED`；若无独立修复，属于高可能受影响；无实机触发证据。
- 缺少准确内核二进制，运行状态保持 `BLOCKED`。新增 4 项自动化测试。
