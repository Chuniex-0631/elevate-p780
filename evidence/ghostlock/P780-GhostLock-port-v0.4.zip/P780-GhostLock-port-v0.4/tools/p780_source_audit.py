#!/usr/bin/env python3
"""Offline source-level pattern checker, not an exploit or proof about firmware.

Requires locally downloaded TinnoOSS/P780 source files. Never reads ADB,
interacts with a device, compiles kernel modules, or generates offsets.
"""
from __future__ import annotations
import argparse
import json
from pathlib import Path
import re


def _uncomment(s: str) -> str:
    # Conservative comment removal for simple C pattern matching. Not a C parser.
    s = re.sub(r'/\*.*?\*/', '', s, flags=re.S)
    return re.sub(r'//[^\n]*', '', s)


def body_of(source: str, function: str) -> str | None:
    clean = _uncomment(source)
    pattern = re.compile(r'\b' + re.escape(function) + r'\s*\([^;{}]*\)\s*\{', re.S)
    for match in pattern.finditer(clean):
        start = match.end()
        nesting = 1
        for i in range(start, len(clean)):
            if clean[i] == '{': nesting += 1
            elif clean[i] == '}':
                nesting -= 1
                if nesting == 0:
                    return clean[start:i]
    return None


def makefile_version(text: str) -> str | None:
    vals = {}
    for name in ('VERSION', 'PATCHLEVEL', 'SUBLEVEL'):
        m = re.search(r'^\s*' + name + r'\s*=\s*(\d+)\s*$', text, re.M)
        if not m: return None
        vals[name] = m.group(1)
    return '.'.join(vals[n] for n in ('VERSION','PATCHLEVEL','SUBLEVEL'))


def review(root: Path) -> dict:
    rt = root/'kernel'/'locking'/'rtmutex.c'
    fut = root/'kernel'/'futex.c'
    mf = root/'Makefile'
    report = {'status':'SOURCE_NOT_PROVIDED','running_kernel_vulnerability':'UNDETERMINED',
              'running_kernel_release':'5.4.233-qgki-gea5245e94afe-dirty',
              'manufacturer_source_version':None, 'errors':[], 'checks':{},
              'source_paths':{'rtmutex':str(rt),'futex':str(fut),'makefile':str(mf)}}
    absent=[str(p) for p in [rt,fut,mf] if not p.is_file()]
    if absent:
        report['missing_sources'] = absent
        return report
    try:
        rt_text=rt.read_text(encoding='utf-8',errors='replace')
        fut_text=fut.read_text(encoding='utf-8',errors='replace')
        mf_text=mf.read_text(encoding='utf-8',errors='replace')
    except OSError as exc:
        report['errors'].append(f'cannot read source: {exc}')
        return report
    version = makefile_version(mf_text)
    report['manufacturer_source_version']=version
    remove = body_of(rt_text,'remove_waiter')
    proxy = body_of(rt_text,'rt_mutex_start_proxy_lock')
    requeue = body_of(fut_text,'futex_requeue')
    old_lock = bool(remove and re.search(r'raw_spin_lock\s*\(\s*&\s*current\s*->\s*pi_lock\s*\)',remove))
    old_clear = bool(remove and re.search(r'current\s*->\s*pi_blocked_on\s*=\s*NULL\s*;',remove))
    fixed_lock = bool(remove and re.search(r'(?:waiter\s*->\s*task|task)\s*->\s*pi_lock',remove))
    fixed_clear = bool(remove and re.search(r'(?:waiter\s*->\s*task|task)\s*->\s*pi_blocked_on\s*=\s*NULL\s*;',remove))
    proxy_rollback = bool(proxy and re.search(r'remove_waiter\s*\(\s*lock\s*,\s*waiter\s*\)',proxy))
    futex_calls_proxy = bool(requeue and re.search(r'\brt_mutex_start_proxy_lock\s*\(',requeue))
    report['checks'] = {
        'remove_waiter_found':remove is not None,
        'proxy_function_found':proxy is not None,
        'futex_requeue_found':requeue is not None,
        'uses_current_pi_lock':old_lock,
        'clears_current_pi_blocked_on':old_clear,
        'mentions_waiter_task_pi_lock':fixed_lock,
        'clears_waiter_task_pi_blocked_on':fixed_clear,
        'proxy_rollback_calls_remove_waiter':proxy_rollback,
        'futex_requeue_calls_proxy_lock':futex_calls_proxy,
        'source_version_differs_from_running_kernel':version != '5.4.233',
    }
    if remove is None or proxy is None or requeue is None or version is None:
        report['status']='SOURCE_INCOMPLETE'
    elif old_lock and old_clear and proxy_rollback and futex_calls_proxy:
        report['status']='OLD_SOURCE_HAS_CVE_LIKE_PATTERN'
    elif fixed_clear and fixed_lock:
        report['status']='SOURCE_HAS_FIX_LIKE_PATTERN'
    else:
        report['status']='SOURCE_PATTERN_INCONCLUSIVE'
    report['warning'] = ('This is a pattern scan of supplied C files, not proof of current firmware patch state, '
                         'runtime exploitability, binary offsets, or bootloader unlock.')
    return report


def main()->int:
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--source-root',type=Path,required=True,help='Directory containing kernel/locking/rtmutex.c, kernel/futex.c, Makefile')
    p.add_argument('--output',type=Path)
    args=p.parse_args()
    result=review(args.source_root.resolve())
    rendered=json.dumps(result,ensure_ascii=False,indent=2)+'\n'
    print(rendered,end='')
    if args.output:
        args.output.parent.mkdir(parents=True,exist_ok=True)
        args.output.write_text(rendered,encoding='utf-8')
    return 2 if result['errors'] else 0

if __name__=='__main__':
    raise SystemExit(main())
