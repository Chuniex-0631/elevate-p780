#!/usr/bin/env python3
"""Compare local vendor and stock Linux v5.4.233 rtmutex sources (offline).

This is a source-level pattern/semantic consistency check, NOT an exploit,
proof of a running device's vulnerable binary, or an offsets generator.
"""
from __future__ import annotations
import argparse
import difflib
import hashlib
import json
from pathlib import Path
import re
from p780_source_audit import body_of


def normalized(body: str) -> str:
    return re.sub(r"\s+", "", body)


def signature(body: str | None) -> dict:
    if body is None:
        return {"function_found": False,"old_pi_lock":False,"old_pi_clear":False,
                "fixed_pi_lock":False,"fixed_pi_clear":False,"old_pattern":False}
    old_l=bool(re.search(r"raw_spin_lock\s*\(\s*&\s*current\s*->\s*pi_lock\s*\)",body))
    old_c=bool(re.search(r"current\s*->\s*pi_blocked_on\s*=\s*NULL\s*;",body))
    fix_l=bool(re.search(r"raw_spin_lock\s*\(\s*&\s*(?:waiter\s*->\s*task|task)\s*->\s*pi_lock\s*\)",body))
    fix_c=bool(re.search(r"(?:waiter\s*->\s*task|task)\s*->\s*pi_blocked_on\s*=\s*NULL\s*;",body))
    return {"function_found":True,"old_pi_lock":old_l,"old_pi_clear":old_c,
            "fixed_pi_lock":fix_l,"fixed_pi_clear":fix_c,
            "old_pattern":old_l and old_c and not(fix_l and fix_c)}


def bridge(vendor_path: Path, upstream_path: Path)->dict:
    report={"status":"INPUT_MISSING","comparison":"VENDOR_VS_UPSTREAM_SOURCE_ONLY",
            "running_kernel_vulnerability":"UNDETERMINED",
            "live_root_safe":False,"missing_inputs":[],"checks":{},"sources":{}}
    for kind,path in [('vendor',vendor_path),('upstream_v5_4_233',upstream_path)]:
        if not path.is_file():
            report['missing_inputs'].append(str(path))
            continue
        raw=path.read_bytes()
        report['sources'][kind]={"path":str(path),"sha256":hashlib.sha256(raw).hexdigest(),"length":len(raw)}
        report['checks'][kind]=signature(body_of(raw.decode('utf-8',errors='replace'),'remove_waiter'))
    if report['missing_inputs']:
        return report
    raw_vendor=vendor_path.read_text(encoding='utf-8',errors='replace')
    raw_upstream=upstream_path.read_text(encoding='utf-8',errors='replace')
    body_v=body_of(raw_vendor,'remove_waiter')
    body_u=body_of(raw_upstream,'remove_waiter')
    same = body_v is not None and body_u is not None and normalized(body_v)==normalized(body_u)
    report['checks']['remove_waiter_body_equal_ignoring_whitespace']=same
    if body_v is not None and body_u is not None and not same:
        report['checks']['remove_waiter_diff_preview']='\n'.join(list(difflib.unified_diff(body_v.splitlines(),body_u.splitlines(),fromfile='vendor_5.4.61',tofile='upstream_5.4.233',lineterm=''))[:100])
    a=report['checks']['vendor']['old_pattern']; b=report['checks']['upstream_v5_4_233']['old_pattern']
    report['status']=('BOTH_SOURCES_SHOW_OLD_PATTERN' if a and b
                      else 'SOURCE_PATTERN_DIFFERS_OR_INCONCLUSIVE')
    report['conclusion'] = ('Upstream stock Linux v5.4.233 and supplied P780 vendor source both retain the CVE-like current/waiter mistake. '
                            'The 2024 vendor-built binary may independently differ. This does NOT validate offsets, runtime exploitability, or bootloader unlock.'
                            if a and b else
                            'The sources supplied do not jointly establish the old pattern; examine source provenance and the diff.')
    return report


def main()->int:
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--vendor-rt',required=True,type=Path)
    p.add_argument('--upstream-rt',required=True,type=Path)
    p.add_argument('--output',type=Path)
    args=p.parse_args()
    report=bridge(args.vendor_rt,args.upstream_rt)
    s=json.dumps(report,indent=2,ensure_ascii=False)+'\n'
    print(s,end='')
    if args.output:
        args.output.parent.mkdir(parents=True,exist_ok=True)
        args.output.write_text(s,encoding='utf-8')
    return 2 if report['missing_inputs'] else 0

if __name__=='__main__':
    raise SystemExit(main())
