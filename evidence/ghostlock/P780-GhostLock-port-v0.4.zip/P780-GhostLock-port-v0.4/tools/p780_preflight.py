#!/usr/bin/env python3
"""P780 offline-only GhostLock port preflight. Python 3.8+, stdlib only.

It audits existing local evidence, never connects to Android, never generates
an exploit binary or an upstream target header, and fails closed by design.
"""
from __future__ import annotations
import argparse
from hashlib import sha256
import gzip
import json
from pathlib import Path
import re
import struct
import sys

EXPECTED_FINGERPRINT = "Rakuten/P780/P780:11/RKQ1.210715.001/264:user/release-keys"

REQUIRED_CONFIG = {
    'CONFIG_FUTEX_PI': 'y',
    'CONFIG_RT_MUTEXES': 'y',
    'CONFIG_ASHMEM': 'y',
    'CONFIG_FTRACE': 'y',
    'CONFIG_RANDOMIZE_BASE': 'y',
    'CONFIG_CFI_CLANG': 'y',
    'CONFIG_PANIC_ON_OOPS': 'y',
}


def digest(path: Path) -> str:
    return sha256(path.read_bytes()).hexdigest()


def parse_config(path: Path) -> dict:
    text = gzip.decompress(path.read_bytes()).decode('utf-8', 'replace')
    values = {}
    for line in text.splitlines():
        match = re.fullmatch(r'(CONFIG_\w+)=(.*)', line)
        if match:
            values[match.group(1)] = match.group(2)
        else:
            match = re.fullmatch(r'# (CONFIG_\w+) is not set', line)
            if match:
                values[match.group(1)] = 'n'
    return {'lines': len(text.splitlines()), 'values': values}


def inspect_trace(path: Path, marker: str) -> dict:
    data = path.read_bytes()
    found = data.find(marker.encode('ascii'))
    result = {'page_size': len(data), 'marker_offset': found,
              'ip_candidate': None, 'ip_offset': None,
              'validated_marker_in_page': False}
    if len(data) >= 16:
        result['commit_len'] = struct.unpack_from('<I', data, 8)[0]
    if len(data) != 4096 or found < 8:
        result['warning'] = 'Unexpected page size or marker has no preceding 8 bytes'
        return result
    ip = struct.unpack_from('<Q', data, found - 8)[0]
    result['ip_candidate'] = f'0x{ip:016x}'
    result['ip_offset'] = f'0x{(ip & 0xfff):03x}'
    result['validated_marker_in_page'] = (ip >> 48) == 0xffff
    result['warning'] = ('Trace record candidate, not _text, not a proven exploit; '
                         'ASLR value is from a previous boot')
    return result


def check(base: Path) -> dict:
    target_file = base / 'target' / 'p780-candidate.json'
    stage_file = base / 'target' / 'upstream-qgki54-snapshot.json'
    target = json.loads(target_file.read_text('utf-8'))
    stage = json.loads(stage_file.read_text('utf-8'))
    evidence = target['evidence']
    result = {
        'target_id': target['target_id'],
        'status': 'BLOCKED',
        'mode': 'OFFLINE_READ_ONLY',
        'errors': [], 'warnings': [], 'checks': {},
    }

    # The whole project is intentionally untrusted until its identity is proven.
    if target['status'] != 'RESEARCH_ONLY_BLOCKED':
        result['errors'].append('unexpected target status; refuse alternate modes')
    if target['identity']['device'] != 'P780' or target['upstream']['stage'] != stage['stage_id']:
        result['errors'].append('unexpected device or stage name')
    if target['identity']['kernel_release'] != '5.4.233-qgki-gea5245e94afe-dirty':
        result['errors'].append('unexpected kernel identity')
    if target['identity']['fingerprint'] != EXPECTED_FINGERPRINT:
        result['errors'].append('unexpected build fingerprint')
    for key in ('generate_payload', 'execute_exploit', 'adb_commands', 'flash_partitions', 'kernel_write'):
        if target['safety_policy'].get(key) is not False:
            result['errors'].append(f'safety policy violation: {key}')
    if target['safety_policy'].get('on_unknown') != 'BLOCK':
        result['errors'].append('safety policy must fail closed')

    for type_, name_key, sha_key in (
        ('config', 'config_file', 'config_sha256'),
        ('trace', 'trace_file', 'trace_sha256'),
    ):
        path = (base / evidence[name_key]).resolve()
        try:
            path.relative_to(base.resolve())
        except ValueError:
            result['errors'].append(f'{type_} evidence path escapes working folder')
            continue
        if not path.is_file():
            result['errors'].append(f'{type_} evidence missing: {path}')
            continue
        actual = digest(path)
        matches = (actual == evidence[sha_key])
        result['checks'][type_ + '_sha256'] = {'match': matches, 'actual': actual}
        if not matches:
            result['errors'].append(f'{type_} hash mismatch; file might have changed')
            continue
        try:
            if type_ == 'config':
                cfg = parse_config(path)
                features = {name: {'expected': needed, 'observed': cfg['values'].get(name),
                                   'match': cfg['values'].get(name) == needed}
                            for name, needed in REQUIRED_CONFIG.items()}
                result['checks']['kernel_config'] = {'lines': cfg['lines'], 'features': features}
                if not all(x['match'] for x in features.values()):
                    result['errors'].append('kernel configuration differs from expected')
            else:
                trace = inspect_trace(path, evidence['trace_marker'])
                result['checks']['trace'] = trace
                if not trace['validated_marker_in_page']:
                    result['errors'].append('trace marker/pointer validation failed')
        except (OSError, EOFError, ValueError, UnicodeError) as exc:
            result['errors'].append(f'{type_} parse failed: {exc}')

    # v0.3: observational build constraints only; never promote to a verified offset.
    if 'kernel_config' in result['checks']:
        config_values = cfg['values']
        additional = (
            'CONFIG_ARM64_VA_BITS', 'CONFIG_ARM64_PAGE_SHIFT',
            'CONFIG_PREEMPT', 'CONFIG_VMAP_STACK', 'CONFIG_LTO_CLANG',
            'CONFIG_CFI_CLANG', 'CONFIG_SHADOW_CALL_STACK',
            'CONFIG_DEBUG_INFO_DWARF4', 'CONFIG_MODULES',
            'CONFIG_MODVERSIONS', 'CONFIG_MODULE_SIG',
            'CONFIG_PANIC_ON_OOPS', 'CONFIG_PANIC_TIMEOUT',
        )
        result['checks']['source_analysis_environment'] = {
            'configuration_only': True,
            'running_kernel_binary_matches_manufacturer_source': 'UNKNOWN',
            'values': {name: config_values.get(name) for name in additional},
        }

    facts = target.get('validated_stage_facts', {})
    required = stage['required_facts']
    # Only two metadata facts have device evidence today.  Do not elevate
    # guessed symbol/structure values into verified status with a free-text
    # provenance string: a future release needs verifiable source binaries.
    permitted = {'BUILD_FINGERPRINT', 'KERNEL_VERSION_CODE'}
    for key in facts:
        if key not in permitted:
            result['errors'].append(f'cannot validate stage fact without exact binary: {key}')

    kernel_release = target['identity']['kernel_release']
    matched_version = re.match(r'^(\d+)\.(\d+)\.(\d+)-', kernel_release)
    derived_code = None
    if matched_version:
        major, minor, patch = map(int, matched_version.groups())
        if not (0 <= major <= 255 and 0 <= minor <= 255 and 0 <= patch <= 255):
            result['errors'].append('kernel version cannot be encoded by KERNEL_VERSION')
        else:
            derived_code = (major << 16) | (minor << 8) | patch
    else:
        result['errors'].append('kernel version not parseable')
    expected_meta = {'BUILD_FINGERPRINT': target['identity']['fingerprint'],
                     'KERNEL_VERSION_CODE': derived_code}

    verified = []
    for key in required:
        if key not in facts:
            continue
        entry = facts[key]
        if (not isinstance(entry, dict)
                or entry.get('verified_for') != target['target_id']
                or entry.get('verification') != 'independently_confirmed'
                or not isinstance(entry.get('evidence_reference'), str)
                or not entry['evidence_reference'].strip()):
            result['errors'].append(f'unverified stage fact: {key}')
            continue
        if key in expected_meta:
            if type(entry.get('value')) != type(expected_meta[key]) or entry.get('value') != expected_meta[key]:
                result['errors'].append(f'mismatched observed stage metadata: {key}')
                continue
            verified.append(key)

    remaining = [key for key in required if key not in verified]
    result['checks']['upstream_stage'] = {
        'stage_id': stage['stage_id'],
        'required_fact_count': len(required),
        'verified_count': len(verified),
        'verified_facts': verified,
        'missing_count': len(remaining),
        'missing_facts': remaining,
        'note': '2 basic metadata values are verified; no kernel code offsets are known.'
    }
    matrix_file = base / 'target' / 'fact-matrix.json'
    if matrix_file.is_file():
        matrix = json.loads(matrix_file.read_text('utf-8'))
        mapped = matrix.get('facts', [])
        if (len(mapped) != len(required) or
            [x.get('key') for x in mapped] != required):
            result['errors'].append('fact-matrix coverage does not match upstream snapshot')
        counts = {}
        for item in mapped:
            cat = item['category']
            counts[cat] = counts.get(cat, 0) + 1
        result['checks']['stage_fact_categories'] = counts
    else:
        result['warnings'].append('fact-matrix unavailable')
    for key, value in target['critical_missing_evidence'].items():
        if value is None:
            result['warnings'].append(f'critical evidence absent: {key}')
    result['checks']['critical_evidence_complete'] = all(
        value is not None for value in target['critical_missing_evidence'].values())

    result['warnings'].append('Do not copy Samsung offsets or trust kernel version alone.')
    result['warnings'].append('This tool NEVER authorizes or runs a live payload.')
    # No code path returns or constructs an executable target. Deliberate.
    return result


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, default=Path(__file__).resolve().parent.parent)
    parser.add_argument('--output', type=Path, help='Optional JSON report path')
    args = parser.parse_args()
    report = check(args.root.resolve())
    rendered = json.dumps(report, indent=2, ensure_ascii=False) + '\n'
    print(rendered, end='')
    if args.output:
        args.output.write_text(rendered, encoding='utf-8')
    return 2 if report['errors'] else 0


if __name__ == '__main__':
    sys.exit(main())
