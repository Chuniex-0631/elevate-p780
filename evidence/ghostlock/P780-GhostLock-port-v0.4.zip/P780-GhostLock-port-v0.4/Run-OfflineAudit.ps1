# Read-only offline audit. Does not call adb or execute any exploit.
$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
Push-Location $root
try {
    if (Get-Command py -ErrorAction SilentlyContinue) {
        & py -3 .\tools\p780_preflight.py --root . --output .\reports\latest-preflight.json
    } elseif (Get-Command python -ErrorAction SilentlyContinue) {
        & python .\tools\p780_preflight.py --root . --output .\reports\latest-preflight.json
    } else {
        throw 'Python 3 is required. Install it, or run the script in any Python 3 environment.'
    }
    if ($LASTEXITCODE -ne 0) { throw "Preflight returned error $LASTEXITCODE" }
    Write-Host 'Offline evidence verification finished. Live exploit remains BLOCKED.'
} finally {
    Pop-Location
}
