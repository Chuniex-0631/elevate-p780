# P780 GhostLock Target：适配工程 v0.3（研究模式）

**状态：Research-only / BLOCKED**  
**设备：Rakuten Hand 5G / P780**  
**当前构建：`P780AE_11.0_RMN_JP_162`**  
**内核：`5.4.233-qgki-gea5245e94afe-dirty` / ARM64**

这是针对该设备的**持续可复核的 Target 基线工程**，而不是 Root APK 或可执行漏洞程序。它可以在 Windows / Linux 上离线检查证据、跟踪上游依赖、识别不匹配的文件、记录待核实参数，且会始终保持实机漏洞运行禁用。

## 已完成的工作

- 登记真实 P780 设备、固件、内核版本、硬件平台、解锁状态。
- 根据 JingMatrix `entry.ghostlock@qgki-5.4` 提取 **31 个构建阶段 required facts**，记录三星环境专属前提。（上游未来更新时应重新核对。）
- 附带你先前提供的 **6,576 行原始运行内核配置** 和 **4,096 字节 Tracefs 原始事件页**，固定 SHA-256。
- 验证 `CONFIG_FUTEX_PI`、`CONFIG_RT_MUTEXES`、`CONFIG_ASHMEM`、`CONFIG_FTRACE` 等配置条件。
- 验证 trace marker `P780_GHOSTLOCK_PROBE` 及其前面的候选 64 位指针 `0xffffffecdc1dc9c8`。**该地址与本次启动状态相关，不是通用地址，更不是 `_text` 基址。**
- 自动标记缺少匹配 `Image`、真实固件漏洞补丁状态、结构布局和 KernelSU 模块等障碍。任何空值/无证据偏移不能进入下一阶段。
- 添加离线单元测试，验证文件被篡改、参数缺少来源、启用危险操作等情况被拒绝。

## Windows PowerShell：立刻验证

解压 ZIP 到电脑后，在工程目录打开 PowerShell，执行：

```powershell
.\Run-OfflineAudit.ps1
```

或直接使用 Python 3：

```powershell
py -3 .\tools\p780_preflight.py --root . --output .\reports\latest-preflight.json
py -3 -m unittest discover -s .\tests -v
```

### 正确的预期结果

- 核心证据校验为 `match: true`。
- Tracefs 中 `validated_marker_in_page: true`。
- `errors: []`。
- `status: "BLOCKED"`：**这是正确且预期的状态，而不是运行失败**。因为尚有 29 个上游构建必需事实未独立验证（2 项基础元数据已确认），当前固件二进制也未取得。

### 文件说明

| 路径 | 内容 |
|---|---|
| `target/p780-candidate.json` | P780 设备身份、证据 SHA、风险边界、尚未确认的内容 |
| `target/upstream-qgki54-snapshot.json` | 2026-10-10 从上游 `stage.toml` 整理的必需参数快照 |
| `evidence/p780-config.gz` | 你手机实际运行内核的压缩配置 |
| `evidence/p780-cpu4.raw` | CPU4 原始追踪记录 |
| `tools/p780_preflight.py` | 离线预检，Python 标准库，不调用 ADB |
| `tools/p780_ghostlock_audit.py` | 上一阶段的源码/文件静态检查工具 |
| `tests/` | 自动回归测试 |
| `reports/initial-preflight.json` | 使用真实上传文件生成的初始结果 |

## 与上游的关系：重要限制

- 这是**独立候选 Target**，未注册进上游 `data/targets.json`，也没有向上游 `cves/targets/` 写入虚构的 `target.h`。
- 上游 Target 使用设备 build + KMI + 镜像偏移组构成严格解析链，仅有设备指纹无法生成有效 payload。上游 QGKI-5.4 成功案例为三星 Galaxy A52s，**并非 P780**。
- 不得复制 Galaxy A52s 的 `init_task`、`SLIDE_TRACE_MARK_IP_OFF`、ashmem、CFI、SELinux 或 pselect 相关值。
- 公开 `TinnoOSS/P780` Linux 5.4.61 源码虽有相同错误模式，但它不同于这台实际的 Linux 5.4.233 `_162` 二进制。不得把旧源码重编译的偏移直接用于实机。
- 本项目不包含 GhostLock 载荷、内核地址修改、KernelSU 模块、Bootloader 写入工具，不连接设备。

## 下一阶段工作（待证据）

1. 以离线静态审计为主，检查 TinnoOSS 旧源码在 `rtmutex.c` 与 `futex.c` 中的逻辑及与 2026 CVE 修复的差异。
2. 继续寻找 **仅用于离线验证** 的 P780 `_162` 匹配内核二进制或可验证的构建来源。已经失败过的 OTA/EDL 搜索不需要重复。
3. 将内核结构型参数、符号型参数、编译栈布局型参数分类，标记每一项的具体证据来源并交叉验证。
4. 只有解决对应构建身份、准确符号/结构以及崩溃恢复条件，才另行设计有风险隔离的实机实验。**本 v0.2 永远不会变成一键执行漏洞的工具。**

## 来源

- 上游目标格式：https://github.com/JingMatrix/pixel-ksu-root/blob/main/cves/targets/README.md
- 上游 QGKI-5.4 stage：https://github.com/JingMatrix/pixel-ksu-root/blob/main/runner/stages/entry.ghostlock%40qgki-5.4/stage.toml
- 上游设备登记：https://github.com/JingMatrix/pixel-ksu-root/blob/main/data/targets.json
- TINNO P780 内核源码：https://github.com/TinnoOSS/P780
- 漏洞 CVE：CVE-2026-43499

所有 SHA-256 与文件解析在本地验证；**文件包不需要连接手机**。

## v0.2：新增资料与限制

- `target/fact-matrix.json`：31 项 required facts 的按证据类型分类清单。
- 对 `BUILD_FINGERPRINT`、`KERNEL_VERSION_CODE` 实施可计算的交叉校验：前者必须与已确认设备指纹一致，后者按 Linux 内核版本编码。预检报告现在应显示 `verified_count: 2`、`missing_count: 29`。
- 新增篡改设备指纹、版本代码等回归测试。其余高风险参数仍不允许手工虚报为已验证。
- 适配状态始终为 `BLOCKED`。**这只是证据分类和检查程序的进展，不是 GhostLock 利用成功率上升的证据**。


## v0.3：TINNO 公开源码静态核对（新增）

v0.3 不是 Root 载荷，而是新增了单独的 `tools/p780_source_audit.py`。它在电脑上扫描**由你自行下载**的三个厂商源码文件：`kernel/locking/rtmutex.c`、`kernel/futex.c`、`Makefile`。

当前网页来源已人工确认：TinnoOSS/P780 的源码基线是 `5.4.61`，`remove_waiter()` 使用 `current` 处理 PI 锁状态、`rt_mutex_start_proxy_lock()` 失败时调用该清理函数、`futex_requeue()` 调用 proxy-lock。它与 2026 年公布的 CVE-2026-43499 修复说明描述的问题一致。**但是你手机实际运行的是 5.4.233；以上不证明实机二进制一定有漏洞。**

### Windows 下载所需源码（仅下载到电脑，不连接手机）

进入 v0.3 工程目录的 PowerShell，执行：

```powershell
$repo = '.\source\TinnoOSS-P780\msm-5.4'
New-Item -ItemType Directory -Force "$repo\kernel\locking" | Out-Null
curl.exe -fL 'https://raw.githubusercontent.com/TinnoOSS/P780/master/msm-5.4/kernel/locking/rtmutex.c' -o "$repo\kernel\locking\rtmutex.c"
curl.exe -fL 'https://raw.githubusercontent.com/TinnoOSS/P780/master/msm-5.4/kernel/futex.c' -o "$repo\kernel\futex.c"
curl.exe -fL 'https://raw.githubusercontent.com/TinnoOSS/P780/master/msm-5.4/Makefile' -o "$repo\Makefile"
py -3 .\tools\p780_source_audit.py --source-root "$repo" --output .\reports\source-audit.json
```

预计的源码分类为 `OLD_SOURCE_HAS_CVE_LIKE_PATTERN`，**并且** `running_kernel_vulnerability` 始终是 `UNDETERMINED`。如果检测值与预期不同，应以实际源码为准，不要强行通过。

`py -3 .\tools\p780_preflight.py --root . --output .\reports\latest-preflight.json` 仍可验证已有的本地证据。新的预检字段 `source_analysis_environment` 会列出 LTO、CFI、栈防护、模块 ABI 等配置，但不会提升漏洞执行权限。`status` 必须继续保持 `BLOCKED`。

### 新的判断标准

- **旧厂商源码层面：** 可复核错误代码模式与函数调用关系。
- **运行中固件：** 尚未验证 `remove_waiter` 是否已修复；缺少完全匹配的 `Image`。
- **真实移植：** 逐构建符号偏移、结构布局、`pselect` 栈布局仍未知；本工程不包含漏洞触发器、载荷或分区写入工具。
- **其他 29 个参数：** 未因为静态源码审阅而被标记成已验证。`verified_count=2` 仍是预期值。

来源及行号记录于 `source/PROVENANCE.json`；源码自身不打包，以避免混淆已复核网页与用户实际下载版本。


## v0.4：新增 Linux 官方 5.4.233 与 P780 厂商旧源码跨版本审计

用户上传的 v0.3 `source-audit.json`：`OLD_SOURCE_HAS_CVE_LIKE_PATTERN`；`errors=[]`；运行内核结论仍是 `UNDETERMINED`。

**新的外部证据（已在线人工核实）**：Linux 官方 `v5.4.233` 的 `kernel/locking/rtmutex.c` 第 1013–1016 行**仍**使用 `current->pi_lock` 和 `current->pi_blocked_on = NULL`；TINNO 5.4.61 源码也存在同一模式。CVE-2026-43499 的公开修复发生于 2026 年 4 月，晚于你的 P780 内核（2024-02-20）。因此，**根据时间和已知源码判断 P780 受影响的可能性较高，但不能证明实际运行的厂商二进制一定存在此漏洞**。

### 可复现离线对比

在 Windows PowerShell 中（位于解压后的 v0.4 目录）：

```powershell
$vendor = '.\source\TinnoOSS-P780\msm-5.4\kernel\locking'
$upstream = '.\source\upstream-5.4.233\kernel\locking'
New-Item -ItemType Directory -Force $vendor, $upstream | Out-Null
curl.exe -fL 'https://raw.githubusercontent.com/TinnoOSS/P780/master/msm-5.4/kernel/locking/rtmutex.c' -o "$vendor\rtmutex.c"
curl.exe -fL 'https://raw.githubusercontent.com/gregkh/linux/v5.4.233/kernel/locking/rtmutex.c' -o "$upstream\rtmutex.c"
py -3 .\tools\p780_version_bridge.py --vendor-rt "$vendor\rtmutex.c" --upstream-rt "$upstream\rtmutex.c" --output .\reports\version-bridge.json
```

预期状态 `BOTH_SOURCES_SHOW_OLD_PATTERN`；`running_kernel_vulnerability` 必须仍是 `UNDETERMINED`。此工具仅在电脑上比较源码，不访问手机、不构建载荷。它不会提高 `verified_count=2/31` 或解除 `BLOCKED`。

官方来源：
- Linux v5.4.233 源码：https://raw.githubusercontent.com/gregkh/linux/v5.4.233/kernel/locking/rtmutex.c
- TINNO 5.4 源码：https://raw.githubusercontent.com/TinnoOSS/P780/master/msm-5.4/kernel/locking/rtmutex.c
- CVE 官方公告：https://lists.openwall.net/linux-cve-announce/2026/05/21/7
- 2026 年 4 月修复记录：https://lists.openwall.net/linux-kernel/2026/04/21/280

### 不能跳过的真正障碍

**仍然没有匹配当前设备的 5.4.233-QGKI `Image` 二进制及符号偏移。** 版本相同的 Linux 上游源码不等于高通／TINNO 的实际二进制。不能使用此检查计算的模式判断直接执行任何 GhostLock 载荷。也不能将 `trace_pipe_raw` 提取到的过往启动地址视为当前启动的 `_text`。
