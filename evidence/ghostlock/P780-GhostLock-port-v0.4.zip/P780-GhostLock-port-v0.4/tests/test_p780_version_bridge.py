"""Cross-version source checks, all offline and device-free."""
import sys,tempfile,unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'tools'))
from p780_version_bridge import bridge, signature
from p780_source_audit import body_of

OLD="""static void remove_waiter(struct rt_mutex *lock, struct rt_mutex_waiter *waiter) {
  raw_spin_lock(&current->pi_lock);
  rt_mutex_dequeue(lock, waiter);
  current->pi_blocked_on = NULL;
  raw_spin_unlock(&current->pi_lock);
}
"""

class BridgeTests(unittest.TestCase):
    def test_both_old_persists_and_no_live_claim(self):
        with tempfile.TemporaryDirectory() as d:
            v=Path(d)/'v.c'; u=Path(d)/'u.c'
            v.write_text(OLD);u.write_text(OLD.replace('  ','    '))
            r=bridge(v,u)
            self.assertEqual(r['status'],'BOTH_SOURCES_SHOW_OLD_PATTERN')
            self.assertFalse(r['live_root_safe'])
            self.assertEqual(r['running_kernel_vulnerability'],'UNDETERMINED')
            self.assertTrue(r['checks']['remove_waiter_body_equal_ignoring_whitespace'])
    def test_one_fixed_prevents_positive(self):
        with tempfile.TemporaryDirectory() as d:
            v=Path(d)/'v.c';u=Path(d)/'u.c'
            v.write_text(OLD)
            u.write_text(OLD.replace('current->pi_lock','waiter->task->pi_lock').replace('current->pi_blocked_on','waiter->task->pi_blocked_on'))
            r=bridge(v,u)
            self.assertEqual(r['status'],'SOURCE_PATTERN_DIFFERS_OR_INCONCLUSIVE')
    def test_missing_input(self):
        r=bridge(Path('/nonexisting-vendor-rt.c'),Path('/nonexisting-upstream-rt.c'))
        self.assertEqual(r['status'],'INPUT_MISSING')
        self.assertTrue(r['missing_inputs'])
    def test_commented_out_example_is_not_finding(self):
        body=body_of('static void remove_waiter(void) { /* raw_spin_lock(&current->pi_lock); current->pi_blocked_on = NULL; */ return; }','remove_waiter')
        self.assertFalse(signature(body)['old_pattern'])

if __name__=='__main__': unittest.main()
