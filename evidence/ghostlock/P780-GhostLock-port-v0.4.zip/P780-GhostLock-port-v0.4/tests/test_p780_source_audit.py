"""Unit tests for the offline TinnoOSS C-source checker. No internet or ADB."""
from pathlib import Path
import sys, tempfile, unittest
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'tools'))
from p780_source_audit import review,body_of,makefile_version

MF='VERSION = 5\nPATCHLEVEL = 4\nSUBLEVEL = 61\n'
PREFIX="""
static void remove_waiter(struct rt_mutex *lock, struct rt_mutex_waiter *waiter)
{
    raw_spin_lock(&current->pi_lock);
    rt_mutex_dequeue(lock, waiter);
    current->pi_blocked_on = NULL;
    raw_spin_unlock(&current->pi_lock);
}
int rt_mutex_start_proxy_lock(struct rt_mutex *lock,struct rt_mutex_waiter *waiter,struct task_struct *task)
{
    if (unlikely(ret)) remove_waiter(lock,waiter);
    return ret;
}
"""
FUT="""static int futex_requeue(int x) {
   ret=rt_mutex_start_proxy_lock(&pi_state->pi_mutex, this->rt_waiter, this->task);
   return ret;
}"""

class StaticSourceTests(unittest.TestCase):
    def mk(self, root, rt=PREFIX,fut=FUT,mf=MF):
        (root/'kernel'/'locking').mkdir(parents=True)
        (root/'kernel'/'locking'/'rtmutex.c').write_text(rt,encoding='utf-8')
        (root/'kernel'/'futex.c').write_text(fut,encoding='utf-8')
        (root/'Makefile').write_text(mf,encoding='utf-8')
    def test_empty_source_is_not_a_success(self):
        with tempfile.TemporaryDirectory() as td:
            report=review(Path(td))
            self.assertEqual(report['status'],'SOURCE_NOT_PROVIDED')
            self.assertEqual(report['running_kernel_vulnerability'],'UNDETERMINED')
    def test_old_source_detected_without_live_claim(self):
        with tempfile.TemporaryDirectory() as td:
            self.mk(Path(td))
            report=review(Path(td))
            self.assertEqual(report['status'],'OLD_SOURCE_HAS_CVE_LIKE_PATTERN')
            self.assertEqual(report['manufacturer_source_version'],'5.4.61')
            self.assertEqual(report['running_kernel_vulnerability'],'UNDETERMINED')
    def test_fixed_like_source_not_mislabeled_old(self):
        with tempfile.TemporaryDirectory() as td:
            patched=PREFIX.replace('current->pi_lock','waiter->task->pi_lock').replace('current->pi_blocked_on','waiter->task->pi_blocked_on')
            self.mk(Path(td),rt=patched)
            report=review(Path(td))
            self.assertEqual(report['status'],'SOURCE_HAS_FIX_LIKE_PATTERN')
    def test_comments_do_not_falsify_pattern(self):
        s="static void remove_waiter(int x) { /* current->pi_blocked_on = NULL; */ call(); }"
        self.assertNotIn('current->pi_blocked_on',body_of(s,'remove_waiter'))
    def test_missing_futex_produces_no_false_pass(self):
        with tempfile.TemporaryDirectory() as td:
            self.mk(Path(td),fut='int xyz(void){return 1;}')
            report=review(Path(td))
            self.assertEqual(report['status'],'SOURCE_INCOMPLETE')
    def test_wrong_version_not_swallowed(self):
        self.assertEqual(makefile_version(MF),'5.4.61')
        self.assertIsNone(makefile_version('VERSION = 5\nPATCHLEVEL = 4'))

if __name__=='__main__': unittest.main()
