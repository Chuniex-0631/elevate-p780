"""Offline regression suite. unittest, no device or network access."""
import json
from pathlib import Path
import shutil
import sys
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'tools'))
from p780_preflight import check


class PreflightTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)
        shutil.copytree(ROOT / 'target', self.root / 'target')
        shutil.copytree(ROOT / 'evidence', self.root / 'evidence')

    def tearDown(self):
        self.tmp.cleanup()

    def target(self):
        path = self.root / 'target' / 'p780-candidate.json'
        obj = json.loads(path.read_text(encoding='utf-8'))
        return path, obj

    def change(self, update):
        path, obj = self.target()
        update(obj)
        path.write_text(json.dumps(obj, indent=2), encoding='utf-8')

    def test_known_evidence_valid_but_exploit_blocked(self):
        report = check(self.root)
        self.assertEqual(report['status'], 'BLOCKED')
        self.assertFalse(report['errors'])
        self.assertTrue(report['checks']['trace']['validated_marker_in_page'])
        self.assertEqual(report['checks']['trace']['ip_candidate'], '0xffffffecdc1dc9c8')
        self.assertEqual(report['checks']['upstream_stage']['verified_count'], 2)
        self.assertEqual(report['checks']['upstream_stage']['missing_count'], 29)
        self.assertFalse(report['checks']['critical_evidence_complete'])

    def test_trace_tamper_is_detected(self):
        path = self.root / 'evidence' / 'p780-cpu4.raw'
        data = bytearray(path.read_bytes())
        data[48] ^= 0x01
        path.write_bytes(data)
        report = check(self.root)
        self.assertTrue(any('hash mismatch' in e for e in report['errors']))

    def test_unverified_offset_not_trusted(self):
        def edit(target):
            target['validated_stage_facts']['INIT_TASK'] = {'value': '0xffffeeee1234'}
        self.change(edit)
        report = check(self.root)
        self.assertTrue(any('cannot validate stage fact' in e for e in report['errors']))

    def test_fingerprint_tamper_is_detected(self):
        self.change(lambda t: t['identity'].__setitem__('fingerprint', 'Fake/Other/Build'))
        report = check(self.root)
        self.assertTrue(any('unexpected build fingerprint' in e for e in report['errors']))

    def test_kernel_version_metadata_tamper_is_detected(self):
        def edit(t):
            t['validated_stage_facts']['KERNEL_VERSION_CODE']['value'] = 1
        self.change(edit)
        report = check(self.root)
        self.assertTrue(any('mismatched observed stage metadata: KERNEL_VERSION_CODE' in e for e in report['errors']))

    def test_fingerprint_metadata_tamper_is_detected(self):
        def edit(t):
            t['validated_stage_facts']['BUILD_FINGERPRINT']['value'] = 'wrong'
        self.change(edit)
        report = check(self.root)
        self.assertTrue(any('mismatched observed stage metadata: BUILD_FINGERPRINT' in e for e in report['errors']))

    def test_safety_flag_never_enabled(self):
        self.change(lambda t: t['safety_policy'].__setitem__('execute_exploit', True))
        report = check(self.root)
        self.assertTrue(any('safety policy violation: execute_exploit' in e for e in report['errors']))

    def test_unsafe_path_rejected(self):
        self.change(lambda t: t['evidence'].__setitem__('trace_file', '../outside.raw'))
        report = check(self.root)
        self.assertTrue(any('escapes working folder' in e for e in report['errors']))


if __name__ == '__main__':
    unittest.main()
