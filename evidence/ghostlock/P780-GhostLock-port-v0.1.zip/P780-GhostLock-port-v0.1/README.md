# P780 GhostLock Target：适配工程 v0.1（研究模式）

**状态：Research-only / BLOCKED**  
**设备：Rakuten Hand 5G / P780**  
**当前构建：`P780AE_11.0_RMN_JP_162`**  
**内核：`5.4.233-qgki-gea5245e94afe-dirty` / ARM64**

这是针对该设备的**第一版可复核的 Target 基线工程**，而不是 Root APK 或可执行漏洞程序。它可以在 Windows / Linux 上离线检查证据、跟踪上游依赖、识别不匹配的文件、记录待核实参数，且会始终保持实机漏洞运行禁用。

## 已完成的工作

- 登记真实 P780 设备、固件、内核版本、硬件平台、解锁状态。
- 根据 JingMatrix `entry.ghostlock@qgki-5.4` 提取 **31 个构建阶段 required facts**，记录三星环境专属前提。（上游未来更新时应重新核对。）
- 附带你先前提供的 **6,576 行原始运行内核配置** 和 **4,096 字节 Tracefs 原始事件页**，固定 SHA-256。
- 验证 `CONFIG_FUTEX_PI`、`CONFIG_RT_MUTEXES`、`CONFIG_ASHMEM`、`CONFIG_FTRACE` 等配置条件。
- 验证 trace marker `P780_GHOSTLOCK_PROBE` 及其前面的候选 64 位指针 `0xffffffecdc1dc9c8`。**该地址与本次启动状态相关，不是通用地址，更不是 `_text` 基址。**
- 自动标记缺少匹配 `Image`、真实固件漏洞补丁状态、结构布局和 KernelSU 模块等障碍。任何空值/无证据偏移不能进入下一阶段。
- 添加离线单元测试，验证文件被篡改、参数缺少来源、启用危险操作等情况被拒绝。

## Windows PowerShell：立刻验证

解压 ZIP 到电脑后，在工程目录打开 PowerShell，执行：

```powershell
.\Run-OfflineAudit.ps1
```

或直接使用 Python 3：

```powershell
py -3 .\tools\p780_preflight.py --root . --output .\reports\latest-preflight.json
py -3 -m unittest discover -s .\tests -v
```

### 正确的预期结果

- 核心证据校验为 `match: true`。
- Tracefs 中 `validated_marker_in_page: true`。
- `errors: []`。
- `status: "BLOCKED"`：**这是正确且预期的状态，而不是运行失败**。因为尚有 31 个上游构建必需事实未独立验证，当前固件二进制也未取得。

### 文件说明

| 路径 | 内容 |
|---|---|
| `target/p780-candidate.json` | P780 设备身份、证据 SHA、风险边界、尚未确认的内容 |
| `target/upstream-qgki54-snapshot.json` | 2026-10-10 从上游 `stage.toml` 整理的必需参数快照 |
| `evidence/p780-config.gz` | 你手机实际运行内核的压缩配置 |
| `evidence/p780-cpu4.raw` | CPU4 原始追踪记录 |
| `tools/p780_preflight.py` | 离线预检，Python 标准库，不调用 ADB |
| `tools/p780_ghostlock_audit.py` | 上一阶段的源码/文件静态检查工具 |
| `tests/` | 自动回归测试 |
| `reports/initial-preflight.json` | 使用真实上传文件生成的初始结果 |

## 与上游的关系：重要限制

- 这是**独立候选 Target**，未注册进上游 `data/targets.json`，也没有向上游 `cves/targets/` 写入虚构的 `target.h`。
- 上游 Target 使用设备 build + KMI + 镜像偏移组构成严格解析链，仅有设备指纹无法生成有效 payload。上游 QGKI-5.4 成功案例为三星 Galaxy A52s，**并非 P780**。
- 不得复制 Galaxy A52s 的 `init_task`、`SLIDE_TRACE_MARK_IP_OFF`、ashmem、CFI、SELinux 或 pselect 相关值。
- 公开 `TinnoOSS/P780` Linux 5.4.61 源码虽有相同错误模式，但它不同于这台实际的 Linux 5.4.233 `_162` 二进制。不得把旧源码重编译的偏移直接用于实机。
- 本项目不包含 GhostLock 载荷、内核地址修改、KernelSU 模块、Bootloader 写入工具，不连接设备。

## 下一阶段工作（待证据）

1. 以离线静态审计为主，检查 TinnoOSS 旧源码在 `rtmutex.c` 与 `futex.c` 中的逻辑及与 2026 CVE 修复的差异。
2. 继续寻找 **仅用于离线验证** 的 P780 `_162` 匹配内核二进制或可验证的构建来源。已经失败过的 OTA/EDL 搜索不需要重复。
3. 将内核结构型参数、符号型参数、编译栈布局型参数分类，标记每一项的具体证据来源并交叉验证。
4. 只有解决对应构建身份、准确符号/结构以及崩溃恢复条件，才另行设计有风险隔离的实机实验。**本 v0.1 永远不会变成一键执行漏洞的工具。**

## 来源

- 上游目标格式：https://github.com/JingMatrix/pixel-ksu-root/blob/main/cves/targets/README.md
- 上游 QGKI-5.4 stage：https://github.com/JingMatrix/pixel-ksu-root/blob/main/runner/stages/entry.ghostlock%40qgki-5.4/stage.toml
- 上游设备登记：https://github.com/JingMatrix/pixel-ksu-root/blob/main/data/targets.json
- TINNO P780 内核源码：https://github.com/TinnoOSS/P780
- 漏洞 CVE：CVE-2026-43499

所有 SHA-256 与文件解析在本地验证；**文件包不需要连接手机**。
